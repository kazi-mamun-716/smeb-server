const router = require("express").Router();
const {
  loggedInUser,
  emailVerification,
  verifyEmail,
  countUser,
  uploadDocument,
  forgotPassword,
  resetPassword,
} = require("../controller/userController");
const upload = require("../lib/multerData");
const verifyToken = require("../utils/verifyToken");

router.get("/loggedInUser", verifyToken, loggedInUser);
router.get("/countMember", verifyToken, countUser);
router.put(
  "/uploadDoc",
  verifyToken,
  upload.fields([
    { name: "ageConfirmation", maxCount: 1 },
    { name: "courseConfirmation", maxCount: 1 },
    { name: "photo", maxCount: 1 },
  ]),
  uploadDocument
);
router.post("/emailVerification", verifyToken, emailVerification);
router.get("/verifyEmail/:id", verifyEmail);
router.post("/forgotPass", forgotPassword);
router.put("/resetPass", resetPassword);

module.exports = router;
