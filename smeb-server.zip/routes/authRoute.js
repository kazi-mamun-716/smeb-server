const upload = require("../lib/multerData");
const router = require("express").Router();
const authController = require('../controller/authController');
const verifyToken = require("../utils/verifyToken");

router.post('/login', authController.login);
router.post('/register',upload.fields([
    {name: "ageConfirmation", maxCount: 1},
    {name: "courseConfirmation", maxCount: 1}
]), authController.register);
router.post('/addMember', authController.addUser);
router.get("/members", authController.getAllUser);
router.put("/approveMember", verifyToken, authController.approveUser);
router.get("/countMember", verifyToken, authController.countUser);
router.route('/:id')
    .get()
    .put(authController.updateUser)
    .delete(authController.deleteUser)
    

module.exports = router;