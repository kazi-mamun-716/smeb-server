const User = require("../model/userModel");
const emailVerification = require("../utils/emailVarification");
const Personal = require("../model/personalModel");
const forgotPassMail = require("../utils/forgotPassMail");
const bcrypt = require("bcrypt");

module.exports = {
  loggedInUser: async (req, res) => {
    const { email } = req.user;
    const user = await User.findOne({ email })
      .select({
        agreeWithCondition: 0,
        password: 0,
        createdAt: 0,
        updatedAt: 0,
        __v: 0,
      })
      .populate("forums", "-author -comments -__v")
      .populate("academicInfo", "-_id -__v -user")
      .populate("personalInfo", "-_id -__v -user");
    res.status(200).json(user);
  },
  uploadDocument: async (req, res) => {
    if (!req.files) {
      console.log("No file received");
      return res.send({
        success: false,
      });
    } else {
      try {
        const host = req.get("host");
        for (let file in req.files) {
          const filePath =
            req.protocol +
            "://" +
            host +
            "/" +
            req.files[file][0].path.replace(/\\/g, "/");
          if (file === "courseConfirmation") {
            const result = await User.findByIdAndUpdate(
              req.user.id,
              {
                $set: { courseConfirmation: filePath },
              },
              {
                new: true,
              }
            );
          } else if (file === "ageConfirmation") {
            const result = await User.findByIdAndUpdate(
              req.user.id,
              {
                $set: { ageConfirmation: filePath },
              },
              {
                new: true,
              }
            );
          } else {
            const result = await User.findByIdAndUpdate(
              req.user.id,
              {
                $set: { photo: filePath },
              },
              {
                new: true,
              }
            );
          }
        }
        res.status(200).json({ message: "Photo Upload Successfully" });
      } catch (err) {
        console.log(err);
        res.status(500).json({
          message: "server error occurd",
        });
      }
    }
  },
  emailVerification: async (req, res) => {
    const { url } = req.body;
    const { email } = req.user;
    emailVerification(email, url);
    res.status(200).json({
      message: "email send successfully",
    });
  },
  verifyEmail: async (req, res) => {
    const { id } = req.params;
    try {
      const result = await User.findByIdAndUpdate(id, {
        $set: {
          emailVerified: true,
        },
      });
      res.status(200).json(result);
    } catch (err) {
      console.log(err);
      res.status(400).json({ message: "User Not Found" });
    }
  },
  countUser: async (req, res) => {
    const count = await User.countDocuments();
    res.status(200).json({ count });
  },
  forgotPassword: async (req, res) => {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (user) {
      forgotPassMail(email, `https://smeb.online/forgotPass/${user._id}`);
      res.status(200).json({
        message: "email sent to your address",
      });
    } else {
      res.status(404).json({
        message: "User Not Found!",
      });
    }
  },
  resetPassword: async (req, res) => {
    try {
      const { id } = req.query;
      const { password } = req.body;
      const user = await User.findById(id);
      if (user) {
        const hashed = await bcrypt.hash(password, 11);
        await User.findByIdAndUpdate(id, { password: hashed });
        res.status(200).json({
          message: "Password Reset Successfull",
        });
      } else {
        res.status(404).json({
          message: "User Not Found!",
        });
      }
    } catch (err) {
      res.status(404).json({
        message: "User Not Found!",
      });
    }
  },
};
