const bcrypt = require("bcrypt");
const User = require("../model/userModel");
const jwt = require("jsonwebtoken");
const Academic = require("../model/academicModel");
const Personal = require("../model/personalModel");
const memberApproval = require("../utils/memberApproval");
const emailVarification = require("../utils/emailVarification");
const { default: mongoose } = require("mongoose");

module.exports = {
  register: async (req, res) => {
    try {
      const {
        name,
        password,
        email,
        gender,
        mobile,
        whatsapp,
        telegram,
        url,
        ...rest
      } = req.body;
      const { course, institute, intake, passed, ...personal } = rest;
      const exists = await User.findOne({ email });
      if (!exists) {
        const hashed = await bcrypt.hash(password, 11);
        const user = await User.create({
          name,
          email,
          password: hashed,
          gender,
          mobile,
          whatsapp,
          telegram,
        });
        const academicInfo = await Academic.create({
          user: user._id,
          course,
          institute,
          intake,
          passed
        });
        const personalInfo = await Personal.create({
          user: user._id,
          ...personal,
        });
        await User.findByIdAndUpdate(user._id, {
          $set: {
            personalInfo: personalInfo._id,
            academicInfo: academicInfo._id,
          },
        });
        emailVarification(email, `${url}/emailVerify/${user._id}`);
        const jwtToken = jwt.sign(
          { id: user._id, name: user.name, email },
          process.env.SECRET
        );
        return res.status(201).json({
          message: "Registration Successfull",
          token: jwtToken,
        });
      }
      return res.status(401).json({
        message: "Member Already Registered",
      });
    } catch (err) {
      console.log(err);
      res.status(500).json({ message: "Internal Server Error!" });
    }
  },
  login: async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({
        message: "User Not Found!",
      });
    }
    const compare = await bcrypt.compare(password, user.password);
    if (!compare) {
      return res.status(401).json({
        message: "Password is incorrect!",
      });
    }
    const jwtToken = jwt.sign(
      { id: user._id, name: user.name, email },
      process.env.SECRET
    );
    res.status(200).json({
      message: "Login Successfull",
      token: jwtToken,
    });
  },
  addUser: async (req, res) => {
    try {
      const { password, email, smebId, ...rest } = req.body;
      const exists = await User.findOne({ email });
      if (!exists) {
        const hashed = await bcrypt.hash(password, 11);
        const idExists = await User.findOne({ smebId });
        if (idExists) {
          return res.status(400).json({
            message: "This SMEB ID alredy given!",
          });
        }
        await User.create({
          email,
          password: hashed,
          smebId,
          status: "active",
          ...rest,
        });
        return res.status(201).json({
          message: "Member Added Successfull",
        });
      }
      return res.status(401).json({
        message: "Member Already Registered",
      });
    } catch (err) {
      console.log("error", err);
      return res.status(500).json({
        message: "Server Side Error!",
      });
    }
  },
  approveUser: async (req, res) => {
    const { id } = req.query;
    const user = await User.findOne({ _id: id });
    let newStatus;
    if (req.body.status === "admin secretary") {
      newStatus = "general secretary";
      const text = `
        Hello ${user.name}, Your application is verified by ${newStatus}
    `;
      memberApproval(user.email, text);
    } else if (req.body.status === "general secretary") {
      newStatus = "president";
      const text = `
        Hello ${user.name}, Your application is verified by ${newStatus}
    `;
      memberApproval(user.email, text);
    } else {
      newStatus = "active";
      const lastUser = await User.findOne({}, {}, { sort: { smebId: -1 } });
      const lastSmebId = lastUser.smebId ? lastUser.smebId : 1014;
      console.log("last", lastSmebId);
      const smebId = lastSmebId + 1;
      await User.findByIdAndUpdate(id, { smebId }, { new: true, upsert: true });
      const text = `
        Hello ${user.name}, congratulation! Your Id are now activated.
    `;
      memberApproval(user.email, text);
    }
    await User.findByIdAndUpdate(id, { status: newStatus }, { new: true });
    res.status(200).json({
      message: "Updated Successfully",
    });
  },
  getAllUser: async (req, res) => {
    const { page, size } = req.query;
    let users;
    if (page || size) {
      users = await User.find()
        .select({
          password: 0,
          __v: 0,
        })
        .limit(parseInt(size))
        .skip(parseInt(size) * parseInt(page))
        .populate("forums", "-author -comments -__v")
        .populate("academicInfo", "-_id -__v -user")
        .populate("personalInfo", "-_id -__v -user");
    } else {
      users = await User.find().select({
        password: 0,
        __v: 0,
      });
    }
    res.status(200).json({ users });
  },
  updateUser: async (req, res) => {},
  deleteUser: async (req, res) => {
    try {
      const { id } = req.params;
      await User.findByIdAndDelete(id);
      await Personal.deleteOne({user: new mongoose.Types.ObjectId(id)});
      await Academic.deleteOne({user: new mongoose.Types.ObjectId(id)});
      res.status(200).json({
        message: "Member Delete Successfully!",
      });
    } catch (err) {
      res.status(500).json({
        message: "Server Side Error!",
      });
      console.log(err);
    }
  },
  countUser: async (req, res) => {
    const count = await User.countDocuments();
    res.status(200).json({ count });
  },
};
