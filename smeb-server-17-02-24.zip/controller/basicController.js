const Academi = require("../model/academiModel")

module.exports={
    allAcademi: async(req, res)=>{
        const academiList = await Academi.find({});
        res.status(200).json(academiList)
    },
    createAcademi: async(req, res)=>{
        const academi = await Academi.create(req.body);
        res.status(201).json({
            message: "Academi Added Successfully"
        })
    },
    academiById: async(req, res)=>{

    }
}