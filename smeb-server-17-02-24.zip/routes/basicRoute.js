const { allAcademi, createAcademi } = require('../controller/basicController');

const router = require('express').Router();

router.route('/academi')
    .get(allAcademi)
    .post(createAcademi)

module.exports = router;