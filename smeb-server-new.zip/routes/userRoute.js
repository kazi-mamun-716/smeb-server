const router = require("express").Router();
const {
  loggedInUser,
  emailVerificationCode,
  countUser,
  uploadDocument,
  forgotPassword,
  resetPassword,
  verifyVCode,
  makePaymentRequest,
  myPayments,
  deletePayment,
} = require("../controller/userController");
const upload = require("../lib/multerData");
const verifyToken = require("../utils/verifyToken");

router.get("/loggedInUser", verifyToken, loggedInUser);
router.get("/countMember", verifyToken, countUser);
router.put(
  "/uploadDoc",
  verifyToken,
  upload.fields([
    { name: "ageConfirmation", maxCount: 1 },
    { name: "courseConfirmation", maxCount: 1 },
    { name: "photo", maxCount: 1 },
  ]),
  uploadDocument
);
router.post("/emailVerification", verifyToken, emailVerificationCode);
router.post("/verifyVCode", verifyToken, verifyVCode);
router.post("/forgotPass", forgotPassword);
router.put("/resetPass", resetPassword);
//payment actions
router.post("/makePaymentRequest", verifyToken, makePaymentRequest);
router.get("/myPayments", verifyToken, myPayments);
router.delete("/payment/:paymentId", verifyToken, deletePayment);

module.exports = router;
