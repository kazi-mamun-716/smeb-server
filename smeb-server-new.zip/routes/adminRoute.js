const router = require("express").Router();
const {
  login,
  register,
  resetPassword,
  allMember,
  countUser,
  loggedInAdmin,
  approveUser,
  changeRole,
  allPaymentRequest,
  allPayment,
  paymentsByMemberId,
  paymentAction
} = require("../controller/adminController");
const verifyAdmin = require("../utils/verifyAdmin");
const verifyToken = require("../utils/verifyToken");

// router.post("/create", register);
router.post("/login", login);
router.put("/restePassword", verifyToken, verifyAdmin, resetPassword);
router.get("/loggedIn", verifyToken, verifyAdmin, loggedInAdmin);
router.get("/allMember", verifyToken, verifyAdmin, allMember);
router.put("/approveMember", verifyToken, verifyAdmin, approveUser);
router.put("/changeRole", verifyToken, verifyAdmin, changeRole);
router.get("/count", verifyToken, verifyAdmin, countUser);

//payment related route
router.get("/allPaymentRequest", verifyToken, verifyAdmin, allPaymentRequest);
router.get("/allPayments", verifyToken, verifyAdmin, allPayment);
router.get("/:id/payments", verifyToken, verifyAdmin, paymentsByMemberId);
router.put("/paymentAction", verifyToken, verifyAdmin, paymentAction);

module.exports = router;
